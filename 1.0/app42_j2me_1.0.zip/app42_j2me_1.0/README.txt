//App42 J2ME SDK
1. UnZip the downloaded file
2. This will contain app42_j2me-X.X.X.jar ,doc, sample folder and README.txt
3. doc folder contains JAVA docs
4. Sample folder contains eclipse sample project for using App42 J2ME SDK.
5. You need to put app42_j2me-X.X.X.jar in classpath of J2ME Project to use this.
6. Please visit http://api.shephertz.com/cloudapidocs/index.php for detail documentaion.